package Itens;

/**
 * ENUM que contém os tipos de herói
 */
public enum TiposHeroi {
    FEITICEIRO,
    CAVALEIRO,
    ARQUEIRO,
}
